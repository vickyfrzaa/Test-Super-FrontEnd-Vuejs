<template>
  <div class="container my-5">
    <div class="row justify-content-center">
      <div class="col-8">
        <div class="card rounded shadow">
          <div class="card-header d-flex justify-content-between fw-bold">
            <div class="p-2 fw-bold judul">Edit To Do List</div>
            <router-link :to="{ name: 'list.index' }" class="btn btn-close btn-sm mb-3 pt-4"></router-link>
          </div>
          <div class="card-body" style="background-color: #f0f8ff">
            <div class="mb-3">
              <label for="exampleFormControlInput1" class="form-label">Name</label>
              <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Name" />
            </div>
            <div class="mb-3">
              <label for="exampleFormControlTextarea1" class="form-label">Description</label>
              <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
            </div>
            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
              <router-link :to="{ name: 'list.index' }" class="btn btn-sm btn-danger pt-1" style="font-size: 17px">Back</router-link>
              <router-link :to="{ name: 'list.index' }" class="btn btn-sm btn-info pt-1" style="font-size: 17px">Add</router-link>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>
