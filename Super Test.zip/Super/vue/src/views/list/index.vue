<template>
  <div class="container my-5">
    <div class="row justify-content-center">
      <div class="col-8">
        <div class="card rounded shadow">
          <div class="card-header d-flex justify-content-between pt-3">
            <div class="p-2 fw-bold judul">To Do List</div>
            <router-link :to="{ name: 'list.create' }" class="btn btn-primary btn-sm rounded-circle shadow mb-2">+</router-link>
          </div>
          <div class="card-body" style="background-color: #f0f8ff">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Name</th>
                  <th>Description</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <!-- Masuk ke database untuk mengganti beberapa validasi menyesuaikan ke database id -->
                <tr>
                  <td>1</td>
                  <td>Vicky</td>
                  <td>Karyawan</td>
                  <td>In Progress</td>
                  <td>
                    <div class="btn-group gap-2">
                      <router-link :to="{ name: 'list.edit', params: { id: 1 } }" class="btn btn-sm btn-outline-info rounded shadow mb-3">Edit</router-link>
                      <button class="btn btn-sm btn-outline-danger rounded shadow mb-3">Delete</button>
                      <button class="btn btn-sm btn-outline-success rounded shadow mb-3">Finished</button>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td>2</td>
                  <td>Fahreza</td>
                  <td>Staff IT</td>
                  <td>In Progress</td>
                  <td>
                    <div class="btn-group gap-2">
                      <router-link :to="{ name: 'list.create' }" class="btn btn-sm btn-outline-info rounded shadow mb-3" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@mdo">Edit</router-link>
                      <!-- Modal -->
                      <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel">Edit ToDoList</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                              <form>
                                <div class="mb-3">
                                  <label for="recipient-name" class="col-form-label">Name:</label>
                                  <input type="text" class="form-control" id="name" />
                                </div>
                                <div class="mb-3">
                                  <label for="message-text" class="col-form-label">Description:</label>
                                  <textarea class="form-control" id="message-text"></textarea>
                                </div>
                              </form>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-outline-info">Edit</button>
                            </div>
                          </div>
                        </div>
                      </div>
                      <!-- <router-link :to="{ name: 'list.edit', parms: { id: 1 } }" class="btn btn-sm btn-outline-info">Edit</router-link> -->
                      <button class="btn btn-sm btn-outline-danger rounded shadow mb-3">Delete</button>
                      <button class="btn btn-sm btn-outline-success rounded shadow mb-3">Finished</button>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td>3</td>
                  <td>Donny</td>
                  <td>Project Manager</td>
                  <td>In Progress</td>
                  <td>
                    <div class="btn-group gap-2">
                      <router-link :to="{ name: 'list.create' }" class="btn btn-sm btn-outline-info rounded shadow mb-3" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@mdo">Edit</router-link>
                      <!-- Modal -->
                      <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel">Edit ToDoList</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                              <form>
                                <div class="mb-3">
                                  <label for="recipient-name" class="col-form-label">Name:</label>
                                  <input type="text" class="form-control" id="name" />
                                </div>
                                <div class="mb-3">
                                  <label for="message-text" class="col-form-label">Description:</label>
                                  <textarea class="form-control" id="message-text"></textarea>
                                </div>
                              </form>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-outline-info">Edit</button>
                            </div>
                          </div>
                        </div>
                      </div>
                      <!-- <router-link :to="{ name: 'list.edit', parms: { id: 1 } }" class="btn btn-sm btn-outline-info">Edit</router-link> -->
                      <button class="btn btn-sm btn-outline-danger rounded shadow mb-3">Delete</button>
                      <button class="btn btn-sm btn-outline-success rounded shadow mb-3">Finished</button>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td>4</td>
                  <td>Rian</td>
                  <td>CEO</td>
                  <td>In Progress</td>
                  <td>
                    <div class="btn-group gap-2">
                      <router-link :to="{ name: 'list.create' }" class="btn btn-sm btn-outline-info rounded shadow mb-3" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@mdo">Edit</router-link>
                      <!-- Modal -->
                      <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel">Edit ToDoList</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                              <form>
                                <div class="mb-3">
                                  <label for="recipient-name" class="col-form-label">Name:</label>
                                  <input type="text" class="form-control" id="name" />
                                </div>
                                <div class="mb-3">
                                  <label for="message-text" class="col-form-label">Description:</label>
                                  <textarea class="form-control" id="message-text"></textarea>
                                </div>
                              </form>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-outline-info">Edit</button>
                            </div>
                          </div>
                        </div>
                      </div>
                      <!-- <router-link :to="{ name: 'list.edit', parms: { id: 1 } }" class="btn btn-sm btn-outline-info">Edit</router-link> -->
                      <button class="btn btn-sm btn-outline-danger rounded shadow mb-3">Delete</button>
                      <button class="btn btn-sm btn-outline-success rounded shadow mb-3">Finished</button>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td>5</td>
                  <td>Dika</td>
                  <td>Marketing</td>
                  <td>In Progress</td>
                  <td>
                    <div class="btn-group gap-2">
                      <router-link :to="{ name: 'list.edit', params: { id: 5 } }" class="btn btn-sm btn-outline-info rounded shadow mb-3">Edit</router-link>
                      <button class="btn btn-sm btn-outline-danger rounded shadow mb-3">Delete</button>
                      <button class="btn btn-sm btn-outline-success rounded shadow mb-3">Finished</button>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import { onMounted, ref } from "vue";

export default {
  // setup() {
  //   let lists = ref([]);
  //   onMounted(() => {
  //      data from api
  //     axios get('data json')
  //     .then((result) => {
  //       lists.value = result.data
  //     )}
  //     .catch((err) => {
  //       console.log(err.response)
  //     });
  //   });
  //   return {
  //     lists
  //   }
  // }
};
</script>
