import { createRouter, createWebHistory } from "vue-router";

const routes = [
  {
    path: "/",
    name: "list.index",
    component: () => import("../views/list/index.vue"),
  },
  {
    path: "/create",
    name: "list.create",
    component: () => import("../views/list/create.vue"),
  },
  {
    path: "/edit/:id",
    name: "list.edit",
    component: () => import("../views/list/edit.vue"),
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
